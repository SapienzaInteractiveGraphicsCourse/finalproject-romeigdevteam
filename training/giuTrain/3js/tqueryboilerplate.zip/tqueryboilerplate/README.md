[boilerplate for tquery](https://github.com/jeromeetienne/tqueryboilerplate)
is a template to get you started. You download it and modify it until it fits your needs.
It is a fast way to start a clean project with [tquery](https://github.com/jeromeetienne/tquery).

## Get Started
```
git clone https://github.com/jeromeetienne/tqueryboilerplate.git
```

And start updating ```index.html``` until it fits yours need.
